package uoit.ca.dsproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.Writer;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class SelectOwnerBlockChain extends AppCompatActivity {
    public static final String TAG = Client.class.getSimpleName();
    public static final int SERVERPORT = 3000;
    public static String SERVER_IP = "YOUR_SERVER_IP";
    TextView messageTv;
    EditText editHash;
    Spinner spinner;
    EditText ownerTaskData;
    public static ArrayList<String> savedHashes;
    public static User serverTaskChains;
    InetAddress inetAddress;
    String ip;
    {
        try {
            inetAddress = InetAddress.getLocalHost();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        try {
            ip = inetAddress.getHostAddress();
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
    }
    public static void writeJson(User user) {
        try (Writer writer = new FileWriter("serverTaskchains.json")) {
            Gson gson = new GsonBuilder().create();
            gson.toJson(user, writer);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void readJson() {
        try (Reader reader = new FileReader("serverTaskchains.json")) {
            Gson gson = new GsonBuilder().create();
            serverTaskChains = gson.fromJson(reader, User.class);
        } catch (Exception e) {
            serverTaskChains = new User();
            e.printStackTrace();
        }
    }

    public static void getAllHashes() {
        serverTaskChains.getSavedHashes();
        savedHashes = serverTaskChains.returnSavedHashes();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_owner_block_chain);
        messageTv = findViewById(R.id.messageTv);
        editHash = findViewById(R.id.editHash);
        spinner = findViewById(R.id.spinner);
        ownerTaskData = findViewById(R.id.taskData);
        Intent i = getIntent();
        serverTaskChains =(User) i.getSerializableExtra("taskchains");
        savedHashes = i.getStringArrayListExtra("saveHashes");
        //readJson();
        //getAllHashes();
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, savedHashes);
        spinner.setAdapter(adapter);
        //???
        spinner.setOnItemClickListener((AdapterView.OnItemClickListener) this);
    }
    //do not need update message-> in main
    public void onClick(View view) {
        try {
            if (view.getId() == R.id.goToStartS) {
                String hash = this.editHash.getText().toString();
                String task = this.ownerTaskData.getText().toString();
                String selectedHash = null;
                if (spinner != null && spinner.getSelectedItem() != null) {
                    selectedHash = (String) spinner.getSelectedItem();
                } else {
                    selectedHash = hash;
                }
                SERVER_IP = ip;
                //messageTv.setText("");
                if (serverTaskChains.findBlockChain(selectedHash)) {
                    serverTaskChains.startBlockChain(task);
                    Intent data = new Intent();
                    data.putExtra("taskchains", serverTaskChains);
                    //clientThread.sendMessage(new Gson().toJson(clientTaskChains));
                    //writeJson(clientTaskChains);
                    //intentViewChain.putExtra("taskchains", (Parcelable) clientTaskChains);
                    setResult(RESULT_OK, data);
                }
            }
            if (view.getId() == R.id.goToAddS) {
                if (view.getId() == R.id.goToStartS) {
                    String hash = this.editHash.getText().toString();
                    String task = this.ownerTaskData.getText().toString();
                    String selectedHash = null;
                    if (spinner != null && spinner.getSelectedItem() != null) {
                        selectedHash = (String) spinner.getSelectedItem();
                    } else {
                        selectedHash = hash;
                    }
                    SERVER_IP = ip;
                    //messageTv.setText("");
                    BlockChain bc = serverTaskChains.getBlockChain(selectedHash);
                    if (bc != null) {
                        serverTaskChains.addToBlockChain(task, bc);
                        Intent data = new Intent();
                        data.putExtra("taskchains", serverTaskChains);
                        //clientThread.sendMessage(new Gson().toJson(clientTaskChains));
                        //writeJson(clientTaskChains);
                        //intentViewChain.putExtra("taskchains", (Parcelable) clientTaskChains);
                        setResult(RESULT_OK, data);
                    }
                }
                if (view.getId() == R.id.backToServer) {
                    finish();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
